const buton =document.getElementsByClassName(".abrirModal")
const modal = document.querySelector("dialog")
buton.onclick = function (){
modal.showModal();
}